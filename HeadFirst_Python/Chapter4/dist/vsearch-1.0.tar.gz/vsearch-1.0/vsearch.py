def search4letters(phrase: str, letters: str = 'aoiue') -> set:
    return set(letters).intersection(set(phrase))